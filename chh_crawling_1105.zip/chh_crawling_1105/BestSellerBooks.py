from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import pandas as pd


# 책 분야 -- > 소설 ~ 청소년
def getBestBooks(result):

    bookStoreURL = 'http://www.kyobobook.co.kr/bestSellerNew/bestseller.laf?orderClick=d79'
    browser = webdriver.Chrome()
    browser.get(bookStoreURL)

    time.sleep(2)

    for p in range(2, 31):
        bookGenre = browser.find_element(By.CSS_SELECTOR, f'#main_contents > div.box_sub_category.fixed_sub_category > ul > li:nth-child({p}) > a')
        bookGenre.click()

        if p == 28:
            continue

        for i in range(1, 21):

            try:
                bookTitleEle = browser.find_element(By.CSS_SELECTOR, f'#main_contents > ul > li:nth-child({i*6}) > div.detail > div.title > a > strong')
                bookCategoryEle = browser.find_element(By.CLASS_NAME, 'title_best_basic')
                bookAuthorEle = browser.find_element(By.CSS_SELECTOR, f'#main_contents > ul > li:nth-child({i*6}) > div.detail > div.author')
                bookPriceEle = browser.find_element(By.CSS_SELECTOR, f'#main_contents > ul > li:nth-child({i*6}) > div.detail > div.price > strong')

                bookCategory = (bookCategoryEle.text).split()
                bookCategory = bookCategory[0].strip()
                bookTitle = bookTitleEle.text
                authorList = (bookAuthorEle.text).split('|')
                author = authorList[0].strip()
                publisher = authorList[1].strip()
                publishDate = authorList[2].strip()
                bookPrice = bookPriceEle.text

                print(f'category : {bookCategory} \t title : {bookTitle} \t author : {author}')
                print(f'publisher : {publisher} \t publishDate : {publishDate}')
                print(f'price : {bookPrice}')

                result.append([bookCategory] + [bookTitle] + [author] + [bookPrice] + [publisher] + [publishDate])

            except Exception as e:
                print(e)

    return





# 책 분야 --> 장르소설
def getBestBooks2(result):

    bookStoreURL = 'http://www.kyobobook.co.kr/bestSellerNew/bestseller.laf?mallGb=EBK&linkClass=08&range=1&kind=0&orderClick=DBk'
    browser = webdriver.Chrome()
    browser.get(bookStoreURL)

    time.sleep(2)

    for p in range(2, 6):
        nextBtn = browser.find_element(By.CSS_SELECTOR,
                                       f'#main_contents > div:nth-child(6) > div.list_paging > ul > li:nth-child({p}) > a')
        nextBtn.click()

        for i in range(1, 21):

            try:
                bookTitleEle = browser.find_element(By.CSS_SELECTOR,
                                                    f'#main_contents > ul > li:nth-child({i * 6}) > div.detail > div.title > a > strong')
                bookCategoryEle = browser.find_element(By.CLASS_NAME, 'title_best_basic')
                bookAuthorEle = browser.find_element(By.CSS_SELECTOR,
                                                     f'#main_contents > ul > li:nth-child({i * 6}) > div.detail > div.author')
                bookPriceEle = browser.find_element(By.CSS_SELECTOR,
                                                    f'#main_contents > ul > li:nth-child({i * 6}) > div.detail > div.price > strong')

                bookCategory = (bookCategoryEle.text).split()
                bookCategory = bookCategory[0].strip()
                bookTitle = bookTitleEle.text
                authorList = (bookAuthorEle.text).split('|')
                author = authorList[0].strip()
                publisher = authorList[1].strip()
                publishDate = authorList[2].strip()
                bookPrice = bookPriceEle.text


                print(f'category : {bookCategory} \t title : {bookTitle} \t author : {author}')
                print(f'publisher : {publisher} \t publishDate : {publishDate}')
                print(f'price : {bookPrice}')

                if bookTitle == '사로잡힌 결혼. 외전':
                    break

                result.append([bookCategory] + [bookTitle] + [author] + [bookPrice] + [publisher] + [publishDate])

            except Exception as e:
                print(e)

    return



def main():

    result = []

    getBestBooks(result)
    getBestBooks2(result)


    bestBooks_tbl = pd.DataFrame(result, columns=('Category', 'Title', 'Author', 'Price', 'Publisher', 'PublishDate'))

    bestBooks_tbl.to_csv('./resources/BestSellerBooks.csv',
                         encoding='cp949',
                         mode='w',
                         index=True)



if __name__ == '__main__':
    main()

