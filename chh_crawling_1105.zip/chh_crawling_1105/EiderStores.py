from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import pandas as pd

def getEiderStores(result):

    eiderURL = 'https://www.eider.co.kr/customercenter/store-info'
    browser = webdriver.Chrome()
    browser.get(eiderURL)

    time.sleep(2)

    # 첫페이지 크롤링
    for i in range(1, 7):

        nameAndPhoneEle = browser.find_element(By.CSS_SELECTOR, f'#shopInfo > tr:nth-child({i}) > td:nth-child(1)')
        addressEle = browser.find_element(By.CSS_SELECTOR, f'#shopInfo > tr:nth-child({i}) > td.al > a')

        nameAndPhone = (nameAndPhoneEle.text).strip()
        nameAndPhoneList = nameAndPhone.split()
        storeName = nameAndPhoneList[0].strip()
        storeCategory = nameAndPhoneList[1].strip()
        storePhone = nameAndPhoneList[2].strip()
        storeAddress = addressEle.text

        print(f'name : {storeName} \t category : {storeCategory} \t phone : {storePhone}')
        print(f'address : {storeAddress}')

    #나머지 페이지 크롤링
    for p in range(1, 51):

        try:
            nextBtn = browser.find_element(By.CSS_SELECTOR, '#pagenation > li.next > a')
            browser.execute_script('arguments[0].click()', nextBtn)

            time.sleep(1)

            for j in range(1, 7):

                nameAndPhoneEle = browser.find_element(By.CSS_SELECTOR, f'#shopInfo > tr:nth-child({j}) > td:nth-child(1)')
                addressEle = browser.find_element(By.CSS_SELECTOR, f'#shopInfo > tr:nth-child({j}) > td.al > a')

                nameAndPhone = (nameAndPhoneEle.text).strip()
                nameAndPhoneList = nameAndPhone.split()
                storeName = nameAndPhoneList[0].strip()
                storeCategory = nameAndPhoneList[1].strip()
                storePhone = nameAndPhoneList[2].strip()
                storeAddress = addressEle.text

                print(f'name : {storeName} \t category : {storeCategory} \t phone : {storePhone}')
                print(f'address : {storeAddress}')

                result.append([storeName] + [storeCategory] + [storePhone] + [storeAddress])

                if p == 50:
                    break

        except Exception as e:
            print(e)

    return


def main():

    result = []

    getEiderStores(result)

    eiderStores_tbl = pd.DataFrame(result, columns=('Name', 'Category', 'Phone', 'Address'))

    eiderStores_tbl.to_csv('./resources/eider.csv',
                           encoding='cp949',
                           mode='w',
                           index=True)



if __name__ == '__main__':
    main()